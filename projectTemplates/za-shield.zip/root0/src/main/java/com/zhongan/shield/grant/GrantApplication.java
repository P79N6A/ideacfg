package com.zhongan.shield.grant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.context.annotation.ImportResource;

/**
 * GrantApplication
 *
 * @author tianshunqian
 * @version 1.0
 * 创建时间 2018/10/30 16:09
 **/
@SpringBootApplication(scanBasePackageClasses = GrantApplication.class)
@ImportResource("classpath:beanRefContext.xml")
@EnableDiscoveryClient
@EnableFeignClients
public class GrantApplication {
    public static void main(String[] args) {
        SpringApplication.run(GrantApplication.class, args);
    }
}
