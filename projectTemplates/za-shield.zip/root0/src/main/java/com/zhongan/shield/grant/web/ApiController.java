package com.zhongan.shield.grant.web;

/**
 * ApiController
 * 对我api
 * @author tianshunqian
 * @version 1.0
 * 创建时间 2018/10/30 16:20
 **/
public class ApiController {
}
