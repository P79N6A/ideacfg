package com.zhongan.shield.grant.config.filter;

import com.zhongan.shield.core.filter.CORSFilter;
import com.zhongan.shield.core.filter.LoginFilter;
import com.zhongan.shield.core.filter.OperateFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.core.Ordered;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import java.util.List;

/**
 * FilterConfig
 *
 * @author tianshunqian
 * @version 1.0
 * 创建时间 2018/10/30 16:22
 **/

public class FilterConfig extends WebMvcConfigurerAdapter {

    @Override
    public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
    }

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**/*").allowedOrigins("*");
    }

    @Bean
    public OperateFilter getOperateFilter() {
        return new OperateFilter();
    }

    @Bean
    public FilterRegistrationBean operateFilter() {
        FilterRegistrationBean registration = new FilterRegistrationBean();
        registration.setFilter(getOperateFilter());
        registration.addUrlPatterns("/*");
        registration.setOrder(Ordered.HIGHEST_PRECEDENCE + 2);
        return registration;
    }

    public LoginFilter getLoginFilter() {
        return new LoginFilter();
    }

    @Bean
    public FilterRegistrationBean loginFilter() {
        FilterRegistrationBean registration = new FilterRegistrationBean();
        registration.setFilter(getLoginFilter());
        registration.addUrlPatterns("/*");
        registration.setName("loginFilter");
        registration.setOrder(Ordered.HIGHEST_PRECEDENCE + 1);
        return registration;
    }

    @Bean
    public CORSFilter getCrossFilter() {
        return new CORSFilter();
    }

    @Bean
    public FilterRegistrationBean crossFilter() {
        FilterRegistrationBean registration = new FilterRegistrationBean();
        registration.setFilter(getCrossFilter());
        registration.addUrlPatterns("/*");
        registration.setOrder(Ordered.HIGHEST_PRECEDENCE);
        return registration;
    }
}
