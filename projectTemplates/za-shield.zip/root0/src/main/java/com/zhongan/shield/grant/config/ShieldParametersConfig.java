package com.zhongan.shield.grant.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties
@Data
public class ShieldParametersConfig {

    @Value("\${za.shield.powercache.url}")
    private String powerCacheUrl;

    @Value("\${za.shield.powercache.namespace}")
    private int powerCacheNamespace;

    @Value("\${za.shield.esDomain}")
    private String esDomain;

    @Value("\${za.shield.oss.endpoint}")
    private String ossEndpoint;
    @Value("\${za.shield.oss.accesskeyid}")
    private String ossAccessKeyId;
    @Value("\${za.shield.oss.accesssecret}")
    private String ossAccessKeySecret;
    @Value("\${za.shield.oss.bucket}")
    private String ossBucket;
    @Value("\${za.shield.phil.domian}")
    private String philDomain;

    @Value("\${za.shield.ftp.ip}")
    private String ftpIp;
    @Value("\${za.shield.ftp.port}")
    private Integer ftpPort;
    @Value("\${za.shield.ftp.user}")
    private String ftpUser;
    @Value("\${za.shield.ftp.password}")
    private String ftpPassword;
    @Value("\${za.shield.ftp.timeout}")
    private Integer ftpTimeOut;

    @Value("\${za.shield.env}")
    private String env;
    @Value("\${za.shield.zk.zkConnectUrl}")
    private String zkConnectUrl;

    @Value("\${za.shield.ons.accessKey}")
    private String accessKey;
    @Value("\${za.shield.ons.secretKey}")
    private String secretKey;
    @Value("\${za.shield.ons.oNSAddr}")
    private String onsAddress;
}
