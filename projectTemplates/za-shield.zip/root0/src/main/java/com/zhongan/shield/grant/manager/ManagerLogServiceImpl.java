package com.zhongan.shield.grant.manager;

import com.zhongan.shield.core.ManagerLogService;
import com.zhongan.shield.core.utils.SsoUtils;
import com.zhongan.sso.client.SsoUser;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

/**
 * ManagerLogServiceImpl
 *
 * @author tianshunqian
 * @version 1.0
 * 创建时间 2018/10/30 16:26
 **/
@Component
@Slf4j
public class ManagerLogServiceImpl implements ManagerLogService {
    @Override
    public void recodeOperator(ServletRequest servletRequest) {
        SsoUser ssoUser = SsoUtils.ensureSSO((HttpServletRequest) servletRequest);
        log.info("操作人:"+ssoUser.getUsername()+";操作日志:"+servletRequest);
    }
}
